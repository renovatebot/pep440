def main():
    print('Hello from mypackage!')